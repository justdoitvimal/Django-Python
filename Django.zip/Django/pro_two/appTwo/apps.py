from django.apps import AppConfig


class ApptwoConfig(AppConfig):
    name = 'appTwo'

from django.shortcuts import render
#from django.http import HttpResponse
from appTwo.models import User
from appTwo.forms import NewUserForm


# Create your views here.

def index(request):
    #Webpage_list=AccessRecord.objects.order_by('date')
    #date_dict={'access_record':Webpage_list}

    #my_dictt={'insert_mee':"Now I am coming from app TWo !!!"}
    return render(request,'appTwo/index.html')


#def help(request):
#    help_dict={'help_insert':'HELP PAGE'}
#    return render(request,'appTwo/help.html',context=help_dict)

def users(request):

    form=NewUserForm()

    if request.method == 'POST':
        form = NewUserForm(request.POST)

        if form.is_valid():
            form.save(commit=True)
            return index(request)

        else:
            print("Error form invalid")

    return render(request ,'appTwo/users.html',{'form' :form})



    #user_list=User.objects.order_by('First_Name')
    #user_dict={'users':user_list}
    #return render(request, "appTwo/users.html",context=user_dict)

from django.contrib import admin
from appTwo.models import User

admin.site.register(User)
#admin.site.register(Topic)
#admin.site.register(Webpage)

# Register your models here.
